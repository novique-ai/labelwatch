# Handoff: LabelWatch — Risk-Meter Cover (V4)

## Overview
A landing-page cover for **LabelWatch**, a recall-intelligence product for dietary-supplement brands. The cover frames the product around a single visceral statistic — the number of recalls in the user's watchlist this month — rendered as a vertical "risk meter" flanked by a typographic headline on the left and the product pitch + email-capture on the right. A horizontal strip below shows three example recalls LabelWatch flagged before the FDA's free email digest landed.

## About the Design Files
The files in this bundle are **design references created in HTML** — a React + inline-styles prototype showing intended look, layout, and content. They are **not production code to copy directly**. The task is to **recreate this design in the target codebase's existing environment** (React, Vue, SwiftUI, native, etc.) using its established patterns, component library, and styling conventions. If no codebase environment exists yet, pick the most appropriate framework and implement there.

The two source files of interest are:
- `v4-cover.jsx` — the React component
- `shared.jsx` — sample recall data and two shared atoms (`ClassPill`, `Placeholder`)

## Fidelity
**High-fidelity.** Final colors, typography, spacing, and copy are settled. Recreate pixel-close, but substitute equivalent components/utilities from the host codebase where they exist (e.g. its own `<Button>`, `<Input>`, layout primitives).

## Screen: Risk-Meter Cover

### Purpose
Above-the-fold landing-page hero. The user lands here and either (a) understands the product instantly via the meter+headline, (b) skims the three recall cards as proof, and (c) drops their email into the capture form on the right.

### Layout (top to bottom)

1. **Top bar** — full-width, 20px / 40px padding, three columns aligned via `display:flex; justify-content:space-between`:
   - Left: brand wordmark "LabelWatch" set in **Instrument Serif italic, 22px**, color `#ece5d6`.
   - Center: tagline "The recall wire for supplement brands" set in **JetBrains Mono, 11px, uppercase, letter-spacing 1.4px**, color `#807a6c`.
   - Right: "Vol. I · Apr 25, 2026" same treatment as center.

2. **Hero row** — 40px / 40px / 60px padding, three columns via CSS grid `1fr 320px 1fr`, `gap: 40px`, `align-items: center`. Heights driven by the meter (~460px).

   **Left column — typographic headline (right-aligned):**
   - Eyebrow: "Volume I · Lead story" — **JetBrains Mono, 11px, uppercase, letter-spacing 2px**, color `#c63a1f`, margin-bottom 20px.
   - Headline: "Three / weeks / behind." stacked across three lines via explicit `<br>`. **Instrument Serif, 88px, weight 400, line-height 0.95, letter-spacing -2.5px**, color `#ece5d6`, `text-align: right`.
   - Body: a single block of small caps copy, max-width 420px, margin-left auto. **JetBrains Mono, 11px, uppercase, letter-spacing 1.2px, line-height 1.7**, color `#9a9485`. Copy: "That's the median lag between an FDA enforcement record going public and the free FDA email digest landing in your inbox. Long enough for your co-packer's other client to ship, recall, and trend on Reddit before you've heard the word 'Salmonella.'"

   **Center column — risk meter:**
   - Outer frame: 240×460px, 1px border `#2a2a26`, border-radius 4px, `overflow: hidden`.
   - Background: `linear-gradient(180deg, rgba(198,58,31,0.18), rgba(20,20,18,0.4))`.
   - Tick scale overlay (full inset): `repeating-linear-gradient(0deg, transparent 0 22px, rgba(255,255,255,0.04) 22px 23px)` to suggest gauge ticks.
   - Fill: absolutely positioned at the bottom, `height: 62%` (this represents 6 of 10 max), with `linear-gradient(180deg, transparent, rgba(198,58,31,0.55) 30%, rgba(198,58,31,0.85))`, and a 2px top border `#c63a1f`.
   - Reading: absolutely positioned at `top: 36%`, full width, centered. Number "6" set in **Instrument Serif, 124px, line-height 0.9, letter-spacing -3px**, color `#fff`. Below it, "recalls / this month" on two lines in **JetBrains Mono, 10px, uppercase, letter-spacing 2px**, margin-top 8px, color `#ece5d6`.
   - Tick labels: positioned `right: -36px`, vertical column from top "10 ─" to bottom "0 ─" in steps of 2. **JetBrains Mono, 9px, color `#807a6c`**.
   - Caption below frame: "3 Class I · in your watchlist" — **JetBrains Mono, 10px, uppercase, letter-spacing 2px, color `#807a6c`**, centered, margin-top 14px.

   **Right column — pitch + capture:**
   - Eyebrow: "What LabelWatch does" — **JetBrains Mono, 10px, uppercase, letter-spacing 2px**, color `#807a6c`, margin-bottom 14px.
   - Pitch (max-width 360px): **Instrument Serif, 22px, line-height 1.32, color `#ece5d6`**. Copy: "Every FDA dietary-supplement recall — normalized, peer-watched on your category, routed to *Slack*, *Teams*, or your webhook, with a CSV audit trail you can hand to a regulator." Use real italics on Slack / Teams / webhook.
   - Sub-pitch: 13px, line-height 1.55, color `#9a9485`, margin-top 18px. Copy: "From $39/mo. The intelligence layer on top of openFDA, built for Shopify-tier supplement brands — not the $500/mo enterprise platforms."
   - Form row: flex, gap 8px, max-width 360px, margin-top 28px.
     - Email input: flex-1, padding `13px 14px`, background `rgba(20,20,18,0.6)`, 1px border `#2a2a26`, color `#ece5d6`, **JetBrains Mono 12px**, border-radius 2px, placeholder "you@brand.com".
     - Submit button: background `#c63a1f`, color `#fff`, padding `13px 18px`, no border, **JetBrains Mono, 11px, uppercase, letter-spacing 1.4px, weight 600**, label "Request access →", border-radius 2px.
   - Fineprint: **JetBrains Mono, 9.5px, uppercase, letter-spacing 1.2px, color `#807a6c`**, margin-top 14px. Copy: "No credit card · founding cohort · one email when we open."

3. **Recall strip** — full-width, 1px top border `#2a2a26`, padding `24px 40px`, background `rgba(10,10,8,0.65)`.
   - Strip header row (flex, justify-content space-between, baseline):
     - Left: "● Found this month — you didn't get the FDA email yet" (the bullet is part of the string).
     - Right: "Showing 3 of 6 · See the full wire →".
     - Both: **JetBrains Mono, 10px, uppercase, letter-spacing 2px, color `#807a6c`**, margin-bottom 16px.
   - Cards grid: CSS grid `repeat(3, 1fr)`, gap 14px. Each card:
     - 1px border `#2a2a26`, padding `16px 18px`, background `rgba(20,20,18,0.5)`, min-height 150px, `display: flex; flex-direction: column; gap: 8px`.
     - Top row (flex, justify-content space-between, align-items center): `<ClassPill>` on the left, "+{N} h ahead" on the right in **JetBrains Mono, 11px, uppercase, letter-spacing 1px, color `#5fd07a`**.
     - Company name: **Instrument Serif, 22px, line-height 1.15, color `#ece5d6`**.
     - Reason (pushed to bottom via `margin-top: auto`): **JetBrains Mono, 10px, uppercase, letter-spacing 0.8px, line-height 1.5, color `#9a9485`**.

### `ClassPill` component
Small inline pill, used inside cards. Background depends on class:
- Class I → `#c63a1f`
- Class II → `#3a3a3a`
- Class III → `#8a8a82`

Color `#fff`, **JetBrains Mono, 10px, weight 600, letter-spacing 0.6px**, padding `3px 7px`. No radius (rectangular). Label format: `CLASS I` / `CLASS II` / `CLASS III`.

## Page background
- Base: `#0e0c0a` (near-black, warm).
- Two soft radial-gradient washes layered on top:
  - `radial-gradient(circle at 80% 20%, rgba(198,58,31,0.18), transparent 50%)`
  - `radial-gradient(circle at 10% 90%, rgba(255,200,140,0.06), transparent 50%)`

These give the page a subtle warm glow on the upper-right (near the meter) and a faint highlight in the lower-left.

## Interactions & Behavior
- **Email form**: on submit, prevent default, POST email to whatever waitlist endpoint the host app uses. Show inline success state ("Got it — we'll email you when LabelWatch opens.") replacing the form. Validate as standard email.
- **"See the full wire →"**: link to the recall feed page (route TBD by the host app).
- **Hover states** (not in mock; please add):
  - CTA button: darken background to `#a82e16`.
  - Recall cards: 1px border lightens to `#3a3a36`, background to `rgba(28,28,24,0.6)`, `cursor: pointer`. Card click → recall detail page.
- **Risk meter is static in this mock.** In production, drive the fill height (`%`) from the live count: `Math.min(count, 10) / 10 * 100`. Animate height on mount with a 600ms ease-out so the meter "fills up" when the user lands.
- **Responsive**: at <960px, collapse the 3-column hero to a single column stacked: meter centered, headline above (left-aligned), pitch below. Recall strip becomes a horizontal scroller (`overflow-x: auto`, snap points).

## State Management
- `email: string` — controlled input.
- `submitted: boolean` — toggles form/success view.
- `recalls: Recall[]` and `total: number`, `class1Count: number` — fetched from the recall API; the mock uses the static `RECALLS` array in `shared.jsx` as the shape reference. See "Data shape" below.

## Data shape

```ts
type Recall = {
  id: string;          // e.g. "F-0421-2026"
  cls: 'I' | 'II' | 'III';
  company: string;
  product: string;     // long descriptive blurb
  reason: string;      // single sentence
  category: string;    // "Botanicals" | "Kratom" | ...
  date: string;        // ISO YYYY-MM-DD
  units: string;       // human-formatted, e.g. "11,400"
  states: string;      // "CA, OR, WA, NV" or "Nationwide"
};

type LeadTime = { id: string; hours: number }; // per recall
```

The cover uses the first 3 recalls and joins each with its `LeadTime.hours` for the "+N h ahead" badge.

## Design Tokens

### Colors
| Token              | Hex / value                          | Use |
|--------------------|--------------------------------------|-----|
| `bg.base`          | `#0e0c0a`                            | Page background |
| `bg.panel`         | `rgba(10,10,8,0.65)`                 | Recall strip |
| `bg.card`          | `rgba(20,20,18,0.5)`                 | Recall card fill |
| `bg.input`         | `rgba(20,20,18,0.6)`                 | Email input fill |
| `border.subtle`    | `#2a2a26`                            | All hairline borders |
| `text.primary`     | `#ece5d6`                            | Headline, brand, body emphasis |
| `text.secondary`   | `#9a9485`                            | Body copy, card reasons |
| `text.muted`       | `#807a6c`                            | Eyebrows, fineprint |
| `signal.red`       | `#c63a1f`                            | Eyebrow, CTA, Class I, meter fill |
| `signal.green`     | `#5fd07a`                            | "+N h ahead" lead-time badge |
| `class.ii`         | `#3a3a3a`                            | Class II pill |
| `class.iii`        | `#8a8a82`                            | Class III pill |
| `glow.warm`        | `rgba(198,58,31,0.18)`               | Upper-right radial wash |
| `glow.cool`        | `rgba(255,200,140,0.06)`             | Lower-left radial wash |

### Typography
Two display + one mono. Load via Google Fonts:
- **Instrument Serif** (regular + italic) — display headline + brand wordmark + card company names + meter number.
- **JetBrains Mono** (400, 500, 600) — all metadata, eyebrows, fineprint, ClassPill, button label, input.
- **Geist** (300–700) — fallback / body sans, currently unused on this view but loaded for the rest of the app.

| Role               | Family             | Size  | Weight | LH    | LS     |
|--------------------|--------------------|-------|--------|-------|--------|
| Brand wordmark     | Instrument Serif   | 22    | 400 i  | —     | -0.5   |
| Big headline       | Instrument Serif   | 88    | 400    | 0.95  | -2.5   |
| Pitch (right col)  | Instrument Serif   | 22    | 400    | 1.32  | 0      |
| Card company name  | Instrument Serif   | 22    | 400    | 1.15  | 0      |
| Meter number       | Instrument Serif   | 124   | 400    | 0.9   | -3     |
| Eyebrow            | JetBrains Mono     | 10–11 | 400    | —     | 1.4–2  |
| Body sub-pitch     | (default sans)     | 13    | 400    | 1.55  | 0      |
| Body small caps    | JetBrains Mono     | 11    | 400    | 1.7   | 1.2    |
| CTA button         | JetBrains Mono     | 11    | 600    | —     | 1.4    |
| Card reason        | JetBrains Mono     | 10    | 400    | 1.5   | 0.8    |
| Lead-time badge    | JetBrains Mono     | 11    | 400    | —     | 1      |
| Fineprint          | JetBrains Mono     | 9.5   | 400    | —     | 1.2    |
| Meter tick labels  | JetBrains Mono     | 9     | 400    | —     | 1.2    |

All JetBrains Mono uses are uppercase except where noted (input placeholder, etc.).

### Spacing
Page outer padding: `40px` horizontal. Hero vertical padding: `40px` top, `60px` bottom. Strip padding: `24px 40px`. Internal column gap: `40px`. Card padding: `16px 18px`.

### Borders & radii
- Hairline: 1px solid `#2a2a26`.
- Meter outer: 4px radius. Input + button: 2px radius. Cards: 0 radius (sharp corners). ClassPill: 0 radius.

### Shadows
None — separation is achieved via borders + background tint. Do not add drop shadows when porting.

## Assets
No image assets. All visuals are CSS-rendered:
- Risk meter — pure CSS (gradients + repeating-linear-gradient for ticks).
- Brand mark — Instrument Serif italic wordmark only; no logo image.
- Background glows — radial gradients.
- Class pill — solid background div.

If the host codebase has its own brand logo, swap the wordmark for it.

## Notes for the implementer
- The mock uses inline `style={}` objects. Port to the host app's styling solution (CSS modules, Tailwind, vanilla-extract, styled-components, etc.) — values are listed above so you don't need to read JSX.
- Sample copy in this README is final. Treat it as canonical.
- The "median 3 weeks behind" claim and "+N h ahead" deltas should be driven by real data once the API is live; in the mock they're static.
- Animate the meter fill on first paint (see Interactions). Everything else is static.

## Files in this bundle
- `README.md` — this document (sufficient on its own).
- `v4-cover.jsx` — source React component (reference only).
- `shared.jsx` — sample data shape + `ClassPill` + `Placeholder` atoms (reference only).
