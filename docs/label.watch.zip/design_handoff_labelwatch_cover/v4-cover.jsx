// V4 — Risk-Meter Cover.
// Idea: campaign-style cover. One visceral hero centered on a vertical risk meter
// counting THIS month's recalls. Below: a scrollable "found this. you didn't." strip.

const v4Styles = {
  page: {
    background: '#0e0c0a',
    color: '#ece5d6',
    fontFamily: "'Geist', system-ui, sans-serif",
    minHeight: 720,
    backgroundImage:
      'radial-gradient(circle at 80% 20%, rgba(198,58,31,0.18), transparent 50%),' +
      'radial-gradient(circle at 10% 90%, rgba(255,200,140,0.06), transparent 50%)',
  },
  topbar: {
    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
    padding: '20px 40px',
    fontFamily: "'JetBrains Mono', monospace",
    fontSize: 11, letterSpacing: 1.4, textTransform: 'uppercase',
    color: '#807a6c',
  },
  brand: {
    fontFamily: "'Instrument Serif', serif", fontSize: 22, fontStyle:'italic',
    textTransform: 'none', letterSpacing: -0.5, color: '#ece5d6',
  },
  hero: {
    padding: '40px 40px 60px',
    display: 'grid', gridTemplateColumns: '1fr 320px 1fr', gap: 40,
    alignItems: 'center',
  },
  bigType: {
    fontFamily: "'Instrument Serif', serif",
    fontWeight: 400, fontSize: 88, lineHeight: 0.95,
    letterSpacing: -2.5, margin: 0, color: '#ece5d6',
    textAlign: 'right',
  },
  bigSub: {
    fontFamily: "'JetBrains Mono', monospace",
    fontSize: 11, letterSpacing: 2, textTransform: 'uppercase',
    color: '#c63a1f', marginBottom: 20, textAlign: 'right',
  },
  rightCol: { paddingLeft: 0 },
  rightHead: {
    fontFamily: "'JetBrains Mono', monospace",
    fontSize: 10, letterSpacing: 2, textTransform: 'uppercase', color: '#807a6c',
    marginBottom: 14,
  },
  rightBody: {
    fontFamily: "'Instrument Serif', serif", fontSize: 22, lineHeight: 1.32,
    color: '#ece5d6', maxWidth: 360,
  },
  rightSmall: { fontSize: 13, lineHeight: 1.55, color: '#9a9485', marginTop: 18, maxWidth: 360 },
  formRow: { marginTop: 28, display: 'flex', gap: 8, maxWidth: 360 },
  input: {
    flex: 1, padding: '13px 14px', background: 'rgba(20,20,18,0.6)',
    border: '1px solid #2a2a26', color: '#ece5d6',
    fontFamily: "'JetBrains Mono', monospace", fontSize: 12, borderRadius: 2,
  },
  cta: {
    background: '#c63a1f', color: '#fff', padding: '13px 18px', border: 'none',
    fontFamily: "'JetBrains Mono', monospace", fontSize: 11, letterSpacing: 1.4,
    textTransform: 'uppercase', fontWeight: 600, cursor: 'pointer', borderRadius: 2,
  },
  fineprint: {
    fontFamily: "'JetBrains Mono', monospace",
    fontSize: 9.5, letterSpacing: 1.2, textTransform: 'uppercase',
    color: '#807a6c', marginTop: 14, maxWidth: 360,
  },

  // Risk meter
  meter: {
    width: 240, height: 460,
    margin: '0 auto', position: 'relative',
    border: '1px solid #2a2a26',
    background: 'linear-gradient(180deg, rgba(198,58,31,0.18), rgba(20,20,18,0.4))',
    borderRadius: 4,
    overflow: 'hidden',
  },
  meterScale: {
    position: 'absolute', inset: 0,
    backgroundImage: 'repeating-linear-gradient(0deg, transparent 0, transparent 22px, rgba(255,255,255,0.04) 22px, rgba(255,255,255,0.04) 23px)',
  },
  meterFillWrap: {
    position: 'absolute', left: 0, right: 0, bottom: 0,
    height: '62%',
    background: 'linear-gradient(180deg, transparent, rgba(198,58,31,0.55) 30%, rgba(198,58,31,0.85))',
    borderTop: '2px solid #c63a1f',
  },
  meterReading: {
    position: 'absolute', left: 0, right: 0, top: '36%',
    textAlign: 'center', color: '#ece5d6',
  },
  meterNum: {
    fontFamily: "'Instrument Serif', serif",
    fontSize: 124, fontWeight: 400, lineHeight: 0.9, color: '#fff',
    letterSpacing: -3,
  },
  meterUnit: {
    fontFamily: "'JetBrains Mono', monospace",
    fontSize: 10, letterSpacing: 2, textTransform: 'uppercase',
    color: '#ece5d6', marginTop: 8,
  },
  meterTicks: {
    position: 'absolute', top: 0, bottom: 0, right: -36,
    display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
    fontFamily: "'JetBrains Mono', monospace",
    fontSize: 9, letterSpacing: 1.2, color: '#807a6c',
  },
  meterCaption: {
    textAlign: 'center', marginTop: 14,
    fontFamily: "'JetBrains Mono', monospace",
    fontSize: 10, letterSpacing: 2, textTransform: 'uppercase',
    color: '#807a6c',
  },

  // Bottom strip
  strip: {
    borderTop: '1px solid #2a2a26',
    padding: '24px 40px',
    background: 'rgba(10,10,8,0.65)',
  },
  stripHead: {
    display:'flex', justifyContent:'space-between', alignItems:'baseline',
    fontFamily: "'JetBrains Mono', monospace",
    fontSize: 10, letterSpacing: 2, textTransform: 'uppercase', color: '#807a6c',
    marginBottom: 16,
  },
  cards: {
    display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)',
    gap: 14,
  },
  card: {
    border: '1px solid #2a2a26',
    padding: '16px 18px', background: 'rgba(20,20,18,0.5)',
    display: 'flex', flexDirection: 'column', gap: 8, minHeight: 150,
  },
  cardCo: {
    fontFamily: "'Instrument Serif', serif", fontSize: 22, lineHeight: 1.15,
    color: '#ece5d6',
  },
  cardReason: {
    fontFamily: "'JetBrains Mono', monospace",
    fontSize: 10, letterSpacing: 0.8, textTransform: 'uppercase',
    color: '#9a9485', lineHeight: 1.5, marginTop: 'auto',
  },
  cardLead: {
    color: '#5fd07a',
    fontFamily: "'JetBrains Mono', monospace",
    fontSize: 11, letterSpacing: 1, textTransform: 'uppercase',
  },
};

const V4Cover = () => {
  const total = RECALLS.length;
  const class1 = RECALLS.filter(r => r.cls === 'I').length;
  return (
    <div style={v4Styles.page}>
      <div style={v4Styles.topbar}>
        <span style={v4Styles.brand}>LabelWatch</span>
        <span>The recall wire for supplement brands</span>
        <span>Vol. I · Apr 25, 2026</span>
      </div>

      <div style={v4Styles.hero}>
        <div>
          <div style={v4Styles.bigSub}>Volume I · Lead story</div>
          <h1 style={v4Styles.bigType}>
            Three<br/>weeks<br/>behind.
          </h1>
          <div style={{
            textAlign:'right', marginTop:18, maxWidth: 420, marginLeft:'auto',
            fontFamily:"'JetBrains Mono', monospace", fontSize:11,
            letterSpacing:1.2, textTransform:'uppercase', color:'#9a9485', lineHeight:1.7,
          }}>
            That's the median lag between an FDA enforcement record going public and the free FDA email digest landing in your inbox. Long enough for your co-packer's other client to ship, recall, and trend on Reddit before you've heard the word "Salmonella."
          </div>
        </div>

        <div>
          <div style={v4Styles.meter}>
            <div style={v4Styles.meterScale} />
            <div style={v4Styles.meterFillWrap} />
            <div style={v4Styles.meterReading}>
              <div style={v4Styles.meterNum}>{total}</div>
              <div style={v4Styles.meterUnit}>recalls<br/>this month</div>
            </div>
            <div style={v4Styles.meterTicks}>
              <span>10 ─</span><span>8 ─</span><span>6 ─</span><span>4 ─</span><span>2 ─</span><span>0 ─</span>
            </div>
          </div>
          <div style={v4Styles.meterCaption}>{class1} Class I · in your watchlist</div>
        </div>

        <div style={v4Styles.rightCol}>
          <div style={v4Styles.rightHead}>What LabelWatch does</div>
          <div style={v4Styles.rightBody}>
            Every FDA dietary-supplement recall — normalized, peer-watched on your category, routed to <i>Slack</i>, <i>Teams</i>, or your webhook, with a CSV audit trail you can hand to a regulator.
          </div>
          <div style={v4Styles.rightSmall}>
            From $39/mo. The intelligence layer on top of openFDA, built for Shopify-tier supplement brands — not the $500/mo enterprise platforms.
          </div>
          <form style={v4Styles.formRow} onSubmit={e=>e.preventDefault()}>
            <input style={v4Styles.input} placeholder="you@brand.com" />
            <button style={v4Styles.cta}>Request access →</button>
          </form>
          <div style={v4Styles.fineprint}>
            No credit card · founding cohort · one email when we open.
          </div>
        </div>
      </div>

      <div style={v4Styles.strip}>
        <div style={v4Styles.stripHead}>
          <span>● Found this month — you didn't get the FDA email yet</span>
          <span>Showing 3 of 6 · See the full wire →</span>
        </div>
        <div style={v4Styles.cards}>
          {RECALLS.slice(0,3).map(r => {
            const lead = LEAD_TIMES.find(l => l.id === r.id)?.hours ?? 0;
            return (
              <div key={r.id} style={v4Styles.card}>
                <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
                  <ClassPill cls={r.cls} />
                  <span style={v4Styles.cardLead}>+{lead} h ahead</span>
                </div>
                <div style={v4Styles.cardCo}>{r.company}</div>
                <div style={v4Styles.cardReason}>{r.reason}</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

window.V4Cover = V4Cover;
