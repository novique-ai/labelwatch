// Shared sample data and tiny presentational atoms used across all variations.

const RECALLS = [
  {
    id: 'F-0421-2026',
    cls: 'I',
    company: 'Ambrosia Brands LLC',
    product: 'Rosabella brand MORINGA; DIETARY SUPPLEMENT CAPSULES; 60 capsules per bottle; Distributed by: Ambrosia Brands.',
    reason: 'Product may be contaminated with Salmonella.',
    category: 'Botanicals',
    date: '2026-02-13',
    units: '11,400',
    states: 'CA, OR, WA, NV',
  },
  {
    id: 'F-0418-2026',
    cls: 'I',
    company: 'Shaman Botanicals, LLC',
    product: 'Product label reads in part as "WHITE VEIN ADVANCED ALKALOIDS CHEWABLE TABLETS 225mg 7-Hydroxymitragynine per tablet".',
    reason: 'A sample of the product revealed the active ingredient is in a quantity greater than the labeled specification.',
    category: 'Kratom',
    date: '2026-02-11',
    units: '4,820',
    states: 'Nationwide',
  },
  {
    id: 'F-0414-2026',
    cls: 'II',
    company: 'Vita-Verde Naturals',
    product: 'Vita-Verde Ashwagandha Root Extract 600mg, 90 vegetarian capsules, Lot #VV-2025-441.',
    reason: 'Undeclared milk allergen detected in finished good; manufactured on shared line.',
    category: 'Adaptogens',
    date: '2026-02-09',
    units: '2,118',
    states: 'CA, TX, FL, NY, IL',
  },
  {
    id: 'F-0410-2026',
    cls: 'II',
    company: 'Heartland Nutrition Co.',
    product: 'Heartland Magnesium Glycinate 400mg gummies, 60ct, multiple flavor SKUs.',
    reason: 'Subpotent; assay results below 80% of label claim at 6-month stability pull.',
    category: 'Minerals',
    date: '2026-02-07',
    units: '38,200',
    states: 'Nationwide',
  },
  {
    id: 'F-0407-2026',
    cls: 'III',
    company: 'Pacific Marine Health',
    product: 'Pacific Krill Oil 1000mg softgels, 120ct.',
    reason: 'Mislabeling — fish allergen statement omitted from secondary panel.',
    category: 'Omega-3',
    date: '2026-02-05',
    units: '6,450',
    states: 'CA, OR, WA',
  },
  {
    id: 'F-0402-2026',
    cls: 'I',
    company: 'NovaPure Labs',
    product: 'NovaPure Pre-Workout Thermogenic, Watermelon, 30 servings.',
    reason: 'Tainted product — undeclared sibutramine identified by FDA lab analysis.',
    category: 'Sports',
    date: '2026-02-01',
    units: '9,910',
    states: 'Nationwide',
  },
];

const CATEGORY_ROLLUP = [
  { name: 'Botanicals',  i: 4, ii: 7,  iii: 2 },
  { name: 'Kratom',      i: 6, ii: 1,  iii: 0 },
  { name: 'Adaptogens',  i: 0, ii: 5,  iii: 3 },
  { name: 'Minerals',    i: 1, ii: 8,  iii: 4 },
  { name: 'Sports',      i: 5, ii: 3,  iii: 1 },
  { name: 'Omega-3',     i: 0, ii: 2,  iii: 4 },
];

// "Lead time" comparison: hours between LabelWatch alert and FDA email-bulletin send.
const LEAD_TIMES = [
  { id: 'F-0421-2026', hours: 71 },
  { id: 'F-0418-2026', hours: 96 },
  { id: 'F-0414-2026', hours: 54 },
  { id: 'F-0410-2026', hours: 112 },
  { id: 'F-0407-2026', hours: 38 },
  { id: 'F-0402-2026', hours: 88 },
];

const ClassPill = ({ cls, style }) => {
  const bg = cls === 'I' ? '#c63a1f' : cls === 'II' ? '#3a3a3a' : '#8a8a82';
  return (
    <span style={{
      background: bg, color: '#fff',
      fontFamily: "'JetBrains Mono', monospace",
      fontSize: 10, fontWeight: 600,
      padding: '3px 7px', letterSpacing: 0.6,
      display: 'inline-block', ...style,
    }}>CLASS {cls}</span>
  );
};

// Striped placeholder for "drop imagery here" moments.
const Placeholder = ({ w='100%', h=200, label='IMAGE', dark=false }) => (
  <div style={{
    width: w, height: h, position:'relative',
    background: dark
      ? 'repeating-linear-gradient(135deg, #1a1a1a 0 8px, #141414 8px 16px)'
      : 'repeating-linear-gradient(135deg, #e8e2d4 0 8px, #ddd6c4 8px 16px)',
    border: dark ? '1px solid #2a2a2a' : '1px solid #c8c0ae',
    color: dark ? '#666' : '#a59c89',
    display:'flex', alignItems:'center', justifyContent:'center',
    fontFamily: "'JetBrains Mono', monospace", fontSize: 11, letterSpacing: 1,
  }}>{label}</div>
);

Object.assign(window, { RECALLS, CATEGORY_ROLLUP, LEAD_TIMES, ClassPill, Placeholder });
